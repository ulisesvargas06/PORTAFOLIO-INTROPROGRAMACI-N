import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n, autMayor=0;
        for (int i = 1; i <= 5; i++) {
            System.out.println("n"+ i+ "=");
            n = s.nextInt();
            if (autMayor < n){
                autMayor = n;
            }
            System.out.println("El mayor es="+autMayor);
        }
    }
}