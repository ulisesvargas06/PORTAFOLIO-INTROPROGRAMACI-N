public class Main {
    public static void main(String[] args) {
        for (int i = 8; i <= 500; i++) {
            if (i%8==0) {
                System.out.println(i);
            }
        }
    }
}