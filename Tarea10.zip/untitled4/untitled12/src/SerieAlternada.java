import java.util.Scanner;

public class SerieAlternada {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leer el valor de N
        System.out.print("Introduce un número entero N: ");
        int N = scanner.nextInt();

        // Inicializar el resultado a 0
        long resultado = 0;

        // Calcular la serie
        for (int i = 1; i <= N; i++) {
            long termino = (long) Math.pow(i, i);
            if (i % 2 == 0) {
                resultado -= termino;
            } else {
                resultado += termino;
            }
        }

        // Imprimir el resultado
        System.out.println("El resultado de la serie es: " + resultado);
    }
}
