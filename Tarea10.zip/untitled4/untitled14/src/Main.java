import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int n;
        boolean primo = true;
        Scanner sc = new Scanner(System.in);
        System.out.println("Número");
        n = sc.nextInt();
        for (int i = n; i >= 2 ; i--) {
            primo = true;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    System.out.println(i + "No es primo");
                    primo = false;
                    break;
                }
            }
            if (primo){
                System.out.println(i + "es primo");
            }
        }
    }
}