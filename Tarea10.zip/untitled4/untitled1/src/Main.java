import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n, autMenor;
        System.out.println("n1=");
        n = s.nextInt();
        autMenor = n;
        for (int i = 1; i <= 5; i++) {
            System.out.println("n"+ i+ "=");
            n = s.nextInt();
            if (autMenor > n){
                autMenor = n;
            }
            System.out.println("El menor es="+ autMenor);
        }
    }
}