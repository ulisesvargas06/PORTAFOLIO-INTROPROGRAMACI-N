public class Main {
    public static void main(String[] args) {
        for (int i = 1; i <= 25; i++){
            System.out.println(i+ ""+ i);
        }
    }
}