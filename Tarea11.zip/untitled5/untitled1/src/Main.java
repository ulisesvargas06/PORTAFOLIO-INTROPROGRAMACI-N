import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner s= new Scanner(System.in);
        int valormenor=Integer.MAX_VALUE, valormayor = 0, valor, valorpel=0;
        for (int i = 1; i <= 5; i++) {
            System.out.println("Glucosa" + i + "=");
            valor = s.nextInt();
            if (valormayor < valor){
                valormayor = valor;
            }
            if (valormenor > valor) {
                valormenor = valor;
            }
            if (valor > 250){
                valorpel++;
            }
        }
        System.out.println("El valor de glucosa mayor es: " + valormayor);
        System.out.println("El valor menor de glucosa es: " + valormenor);
        System.out.println("Tuvo un nivel peligroso de glucosa " + valorpel + "veces");
    }
}