public class Main {
    public static void main(String[] args) {
        int n=3;
        while (n<35) {
            if (n%2==0){
                n+=3;
            }
            else {
                n+=4;
            }
            System.out.println(n);
        }
    }
}