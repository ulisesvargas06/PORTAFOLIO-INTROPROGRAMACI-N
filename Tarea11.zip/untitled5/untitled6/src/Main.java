public class Main {
    public static void main(String[] args) {
        int vector [] = new int[5];
        vector[0]=2;
        vector[1]=4;
        vector[2]=6;
        vector[3]=8;
        vector[4]=10;
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Estoy en el indice" + i);
            System.out.println("Tengo guardado un" + vector[i]);
            System.out.println("-------------------------");
        }
    }
}