public class Main {
    public static void main(String[] args) {
        int n=3;
        for (int i = 1; i < 8; i++) {
            n = n * 2;
            if (n%4==0)
                System.out.println(n);
        }
    }
}