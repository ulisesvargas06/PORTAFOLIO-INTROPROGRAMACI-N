import java.util.Scanner;
public class vectoresmyr {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int acumMayor=0;
        int vector[] = new int[5];
        System.out.println("Introduzca el valor de los vectores: ");
        for (int j = 0; j < vector.length; j++) {
            vector[j] = sc.nextInt();
        }

        int acumMenor = Integer.MAX_VALUE;
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Estoy en el indice: " + i);
            System.out.println("Tengo guardado un: " + vector[i]);
            System.out.println("---------------------");
            if (vector[i] > acumMayor) {
                acumMayor = vector[i];
            }
            if (acumMenor > vector[i]) {
                acumMenor = vector[i];
            }
        }
        System.out.println("El Mayor es: " + acumMayor);
        System.out.println("El Menor es: " + acumMenor);
        }
    }
