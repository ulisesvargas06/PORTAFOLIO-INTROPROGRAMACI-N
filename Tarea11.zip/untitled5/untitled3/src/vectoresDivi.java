import java.util.Scanner;

public class vectoresDivi {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int vector [] = new int[5];
        System.out.println("Introduzca el valor de los vectores: ");
        for (int j = 0; j < vector.length; j++) {
            vector[j] = sc.nextInt();
        }
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Estoy en el indice: " + i);
            System.out.println("Tengo guardado un: " + vector[i]);
            System.out.println("Los divisores de" + vector[i] + "son: ");

        for (int j = 1; j <= vector.length; j++) {
            if (vector[i] % j == 0) {
                System.out.println(j);
            }
        }
            System.out.println("---------------------");
        }
        }
    }
