import java.util.Scanner;
public class vectores {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int suma=0;
        int vector [] = new int[5];
        System.out.println("Introduzca el valor de los vectores: ");

        for (int j = 0; j < vector.length; j++) {
            vector[j] = sc.nextInt();
        }
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Estoy en el indice: " + i);
            System.out.println("Tengo guardado un: " + vector[i]);
            System.out.println("---------------------");
            suma = vector[i] + suma;
        }
        System.out.println("La suma es de estos numeros es: " + suma);
        }
    }
